package com.rocketmq.clientdemo.Client;

import com.rocketmq.clientdemo.component.config.ConsumerConf;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.listener.*;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.common.message.MessageQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * @author liuxinghong
 * @Description: 普通消费者
 * @date 2018/12/27/02716:27
 */
public class Consumer {
    private static Logger LOG = LoggerFactory.getLogger(Consumer.class);
    private static final Map<MessageQueue, Long> OFFSE_TABLE = new HashMap<MessageQueue, Long>();


    public static void consumer( DefaultMQPushConsumer consumer,ConsumerConf config){
        try {
            //consumer.setVipChannelEnabled(true);
            consumer.subscribe(config.getTopic(),config.getTags());
            consumer.setNamesrvAddr(config.getServerIpPort());
            consumer.setConsumeFromWhere(config.getConsumeFrom());
            consumer.setMessageModel(config.getMessageModel());//消费模式：集群消费
            //可以修改每次消费消息的数量，默认设置是每次消费一条
             consumer.setConsumeMessageBatchMaxSize(1);
            consumer.registerMessageListener(new MessageListenerConcurrently() {
                @Override
                public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                    try {
                        LOG.info("开始接收消息》》》》》》》》~~~~~~~");
                        for(MessageExt item : msgs){
                            //处理业务
                            LOG.info("MessageExt:---"+item.getTopic()+"---tag："+item.getTags() +"---key"+item.getKeys()+ new String(item.getBody(),"utf-8")+"队列id："+item.getQueueId());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        return ConsumeConcurrentlyStatus.RECONSUME_LATER;
                    }
                    LOG.info("context:---" + context.getMessageQueue().toString());
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }
            });

            consumer.start();
            LOG.info("消费者启动成功》》》》......");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void consumerOrderly(DefaultMQPushConsumer consumer,ConsumerConf config){
        try {
            //consumer.setVipChannelEnabled(true);
            consumer.subscribe(config.getTopic(),config.getTags());
            consumer.setNamesrvAddr(config.getServerIpPort());
            consumer.setConsumeFromWhere(config.getConsumeFrom());
            consumer.setMessageModel(config.getMessageModel());//消费模式：集群消费
            //可以修改每次消费消息的数量，默认设置是每次消费一条
             consumer.setConsumeMessageBatchMaxSize(1);
            consumer.registerMessageListener(new MessageListenerOrderly() {
                @Override
                public ConsumeOrderlyStatus consumeMessage(List<MessageExt> msgs, ConsumeOrderlyContext context) {
                    try {
                    context.setAutoCommit(true);
                    LOG.info(Thread.currentThread().getName() + " Receive New Messages: " );
                    for (MessageExt msg: msgs) {
                        LOG.info("MessageExt:---"+msg.getTopic()+msg.getTags() + new String(msg.getBody(),"utf-8"));
                       LOG.info(msg + ", content:" + new String(msg.getBody()));
                    }
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                        return ConsumeOrderlyStatus.SUSPEND_CURRENT_QUEUE_A_MOMENT;
                    }
                    return ConsumeOrderlyStatus.SUCCESS;
                }
            });
            consumer.start();
            LOG.info("消费者启动成功》》》》......");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }





}
