package com.rocketmq.clientdemo.Client;

import com.rocketmq.clientdemo.component.config.ProducerConfig;
import org.apache.rocketmq.client.MQAdmin;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.impl.MQAdminImpl;
import org.apache.rocketmq.client.impl.MQClientManager;
import org.apache.rocketmq.client.impl.factory.MQClientInstance;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.MQProducer;
import org.apache.rocketmq.remoting.common.RemotingUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuxinghong
 * @Description: mq客户端
 * @date 2018/12/27/02714:10
 */
public class ProducerUtils {


    private static Logger LOG = LoggerFactory.getLogger(ProducerUtils.class);

    /**
     * 创建普通生产者
     *
     * @param config 配置参数
     */
    public static DefaultMQProducer getDefaultMQProducer(ProducerConfig config) throws MQClientException {

        DefaultMQProducer producer = new DefaultMQProducer(config.getProducerGroup());
        producer.setNamesrvAddr(config.getServerIpPort());
        producer.setDefaultTopicQueueNums(30);//在发送消息时，自动创建服务器不存在的topic，默认创建的队列数
        producer.setSendMsgTimeout(10000);//设置发送消息超时时间
        producer.setRetryAnotherBrokerWhenNotStoreOK(true);//如果发送消息返回 sendResult，但是sendStatus!=SEND_OK，是否重试发送
        producer.setSendMessageWithVIPChannel(true);//是否使用vip通道进行发送
        producer.setClientIP(RemotingUtil.getLocalAddress());//客户端ip
        producer.start();
        return producer;
    }





}
