package com.rocketmq.clientdemo.Client;

import com.alibaba.fastjson.JSONObject;
import com.rocketmq.clientdemo.component.config.ProducerConfig;
import org.apache.rocketmq.client.exception.MQBrokerException;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.MessageQueueSelector;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.common.message.MessageQueue;
import org.apache.rocketmq.remoting.exception.RemotingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author liuxinghong
 * @Description:
 * @date 2018/12/27/02716:25
 */
public class SendMessage {

    private static Logger LOG = LoggerFactory.getLogger(SendMessage.class);
    /**
     * 发送普通消息（无序）
     *
     * @param producer
     */
    public static void sendGeneralMessage(DefaultMQProducer producer, ProducerConfig serverConfig) {
        Message message = new Message();
        message.setTopic(serverConfig.getTopic());
        message.setDelayTimeLevel(serverConfig.getDelayLevel());//延迟等级1  代表一秒
        message.setTags(serverConfig.getTag()); //TAG 设置
        message.setKeys(serverConfig.getKey());
        message.setBody((serverConfig.getBody()).getBytes());
        try {
            //队列判断,若输入队列超过设置的队列或为空  给一个默认的队列
            List<MessageQueue> messageQueues = producer.getDefaultMQProducerImpl().fetchPublishMessageQueues(serverConfig.getTopic());
            if (serverConfig.getQueueId()>=messageQueues.size()-1){
                producer.createTopic(serverConfig.getTopic(),serverConfig.getTopic(),serverConfig.getQueueId()+1,0);
            }
            if (null==serverConfig.getQueueId() ){
                throw new Exception("队列id不能为空！");
            }
            SendResult send = producer.send(message,20000);
            LOG.info("消息发送成功》》》》》！--时间:" + System.currentTimeMillis() + " >>tag:" + serverConfig.getTag() + "  >>消息内容:" + JSONObject.toJSONString(serverConfig.getBody()));
        } catch (MQClientException | MQBrokerException | RemotingException | InterruptedException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    /**
     * 有序消息发送一次发送到指定队列
     * @param producer   发送者
     * @throws InterruptedException
     * @throws RemotingException
     * @throws MQClientException
     * @throws MQBrokerException
     */
    public static void sendOrderlyMessage(DefaultMQProducer producer, ProducerConfig serverConfig) throws Exception {
        Message message = new Message();
        message.setTopic(serverConfig.getTopic());
        message.setDelayTimeLevel(serverConfig.getDelayLevel());//延迟等级1  代表一秒
        message.setTags(serverConfig.getTag()); //TAG 设置
        message.setKeys(serverConfig.getKey());
        message.setBody(serverConfig.getBody().getBytes());
        //队列判断,若输入队列超过设置的队列或为空  给一个默认的队列
        List<MessageQueue> messageQueues = producer.getDefaultMQProducerImpl().fetchPublishMessageQueues(serverConfig.getTopic());
    if (serverConfig.getQueueId()>=messageQueues.size()-1){
        producer.createTopic(serverConfig.getTopic(),serverConfig.getTopic(),serverConfig.getQueueId()+1,0);
    }
        if (null==serverConfig.getQueueId() ){
            throw new Exception("队列id不能为空！");
        }
            SendResult send = producer.send(message, new MessageQueue(serverConfig.getTopic(),serverConfig.getBrokerName(), serverConfig.getQueueId()));
            LOG.info("消息发送成功》》》》》！--时间:" + System.currentTimeMillis() + " >>tag:" + serverConfig.getTag() + "  >>消息内容:" + JSONObject.toJSONString(serverConfig.getBody())+"消息队列："+serverConfig.getQueueId());
        }

}