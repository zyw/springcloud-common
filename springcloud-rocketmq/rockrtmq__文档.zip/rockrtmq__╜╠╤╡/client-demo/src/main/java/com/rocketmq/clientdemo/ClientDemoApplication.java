package com.rocketmq.clientdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author liuxinghong
 * @Description:
 * @date 2018/12/6/00610:38
 */
@SpringBootApplication
public class ClientDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientDemoApplication.class, args);
	}

}

