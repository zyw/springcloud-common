package com.rocketmq.clientdemo.component.config;

import org.apache.rocketmq.client.MQAdmin;
import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
import org.apache.rocketmq.common.protocol.heartbeat.MessageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @author liuxinghong
 * @Description:
 * @date 2018/12/6/00612:30
 */
@Configuration
@ConfigurationProperties(prefix = "consumer")
public class ConsumerConf {

    private String serverIpPort;
    private String producerGroup;
    private String topic;
    private String tags="*"; //tag 默认全部订阅
    private MessageModel messageModel; //消费方式 集群 || 广播
    private ConsumeFromWhere ConsumeFrom;//消费起点


    public String getServerIpPort() {
        return serverIpPort;
    }

    public void setServerIpPort(String serverIpPort) {
        this.serverIpPort = serverIpPort;
    }

    public String getProducerGroup() {
        return producerGroup;
    }

    public void setProducerGroup(String producerGroup) {
        this.producerGroup = producerGroup;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public MessageModel getMessageModel() {
        return messageModel;
    }

    public void setMessageModel(MessageModel messageModel) {
        this.messageModel = messageModel;
    }

    public ConsumeFromWhere getConsumeFrom() {
        return ConsumeFrom;
    }

    public void setConsumeFrom(ConsumeFromWhere consumeFrom) {
        ConsumeFrom = consumeFrom;
    }
}
