package com.rocketmq.clientdemo.component.config;

import org.apache.rocketmq.common.protocol.body.ProducerConnection;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author liuxinghong
 * @Description: rocketmq服务器配置
 * @date 2018/12/6/00611:35
 */
@Configuration
@ConfigurationProperties(prefix = "producer")
public class ProducerConfig {

    private String producerGroup; //生产组
    /**
     * broker ip+port 集群 "ip1:port1;ip2:port2"
     */
    private String serverIpPort; // 服务器ip+port
    private String topic; //主题
    private Integer delayLevel; //延迟级别
    private String tag; //tag标签
    private String key;//key 用来表示
    private String body; //消息体
    private String brokerName; // brokername
    private Integer queueId;  //队列序号

    public String getProducerGroup() {
        return producerGroup;
    }

    public void setProducerGroup(String producerGroup) {
        this.producerGroup = producerGroup;
    }

    public String getServerIpPort() {
        return serverIpPort;
    }

    public void setServerIpPort(String serverIpPort) {
        this.serverIpPort = serverIpPort;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public Integer getDelayLevel() {
        return delayLevel;
    }

    public void setDelayLevel(Integer delayLevel) {
        this.delayLevel = delayLevel;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getBrokerName() {
        return brokerName;
    }

    public void setBrokerName(String brokerName) {
        this.brokerName = brokerName;
    }

    public Integer getQueueId() {
        return queueId;
    }

    public void setQueueId(Integer queueId) {
        this.queueId = queueId;
    }

    @Override
    public String toString() {
        return "RocketMqServerConfig{" +
                "producerGroup='" + producerGroup + '\'' +
                ", serverIpPort='" + serverIpPort + '\'' +
                ", topic='" + topic + '\'' +
                ", delayLevel=" + delayLevel +
                ", tag='" + tag + '\'' +
                ", key='" + key + '\'' +
                ", body='" + body + '\'' +
                ", brokerName='" + brokerName + '\'' +
                ", queueId=" + queueId +
                '}';
    }
}
