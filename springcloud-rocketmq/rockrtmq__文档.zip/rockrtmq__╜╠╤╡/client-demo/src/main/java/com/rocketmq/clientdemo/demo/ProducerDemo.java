package com.rocketmq.clientdemo.demo;

import com.rocketmq.clientdemo.Client.Consumer;
import com.rocketmq.clientdemo.Client.ProducerUtils;
import com.rocketmq.clientdemo.Client.SendMessage;
import com.rocketmq.clientdemo.component.config.ConsumerConf;
import com.rocketmq.clientdemo.component.config.ProducerConfig;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
import org.apache.rocketmq.common.protocol.heartbeat.MessageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @author liuxinghong
 * @Description:
 * @date 2018/12/27/02717:26
 */
@Component
public class ProducerDemo {

    @Autowired
    private ProducerConfig serverConfig;
    @Autowired
    private ConsumerConf consumerConf;


    @PostConstruct
    public void producer() {
        try {
            serverConfig.setBrokerName("7e13d3bd4a47");
            serverConfig.setDelayLevel(0);
            serverConfig.setKey("");
            serverConfig.setQueueId(2);
            serverConfig.setTag("*");
            DefaultMQProducer producer = ProducerUtils.getDefaultMQProducer(serverConfig);

            for (int i = 1; i < 50; i++) {
                //有序
                serverConfig.setBody(System.currentTimeMillis() + "--第" + i + "条数据！");
               // SendMessage.sendOrderlyMessage(producer, serverConfig);//有序消息
                 SendMessage.sendGeneralMessage(producer,serverConfig);//普通消息
            }
            producer.shutdown();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @PostConstruct
    public void comsur() {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(consumerConf.getProducerGroup());
        consumerConf.setConsumeFrom(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
        consumerConf.setMessageModel(MessageModel.BROADCASTING);//消费模式
        String tags = new StringBuffer().append("002").append("||").append("001").append("||").append("007").toString();
        //consumerConf.setTags(tags.trim());//根据tag订阅
        // Consumer.consumerOrderly(consumer,consumerConf);//顺序消费
        Consumer.consumer(consumer, consumerConf);//普通消费(有序发送 消费为有序)
    }

}
